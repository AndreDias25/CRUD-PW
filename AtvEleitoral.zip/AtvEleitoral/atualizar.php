<!DOCTYPE html>
<html lang="pt">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
   <title>Apuração Eleitoral</title>
</head>

<body>
   <form method="POST" name="dados" action="update.php" onSubmit="return enviardados();">

      <table width="588" border="0" align="center">
         <tr>
            <td width="118">
               <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Nome completo:</font>
            </td>
            <td width="460">
               <input name="nome" type="text" class="formbutton" id="nome" size="52" maxlength="150">
            </td>
         </tr>

         <tr>
            <td>
               <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Data de nascimento:</font>
            </td>
            <td>
               <font size="2">
                  <input name="datadeNascimento" type="date" id="datadeNascimento" class="formbutton">
               </font>
            </td>
         </tr>

         <tr>
            <td>
               <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Nº do documento:</font>
            </td>
            <td>
               <font size="2">
                  <input name="numeroDocumento" type="text" id="numeroDocumento" size="52" maxlength="150" class="formbutton">
               </font>
            </td>
         </tr>

         <tr>
            <td>
               <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Data de expedição:</font>
            </td>
            <td>
               <font size="2">
                  <input name="dataExpedicao" type="date" id="dataExpedicao" size="52" maxlength="150" class="formbutton">
               </font>
            </td>
         </tr>

         <tr>
            <td>
               <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Naturalidade:</font>
            </td>
            <td>
               <font size="2">
                  <input name="Naturalidade" type="text" id="Naturalidade" size="52" maxlength="150" class="formbutton">
               </font>
            </td>
         </tr>
         <tr>
            <td>
               <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Cidade:</font>
            </td>
            <td>
               <font size="2">
                  <input name="Cidade" type="text" id="Cidade" size="52" maxlength="150" class="formbutton">
               </font>
            </td>
         </tr>

         <tr>
            <td width="118">
               <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Nome do pai:</font>
            </td>
            <td width="460">
               <input name="nomePai" type="text" class="formbutton" id="nomePai" size="52" maxlength="150">
            </td>
         </tr>

         <tr>
            <td width="118">
               <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Nome da mãe:</font>
            </td>
            <td width="460">
               <input name="nomeMae" type="text" class="formbutton" id="nomeMae" size="52" maxlength="150">
            </td>
         </tr>

         <tr>
            <td width="118">
               <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Seção:</font>
            </td>
            <td width="460">
               <input name="Secao" type="text" class="formbutton" id="Secao" size="52" maxlength="150">
            </td>
         </tr>

         <tr>
            <td width="118">
               <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Zona eleitoral:</font>
            </td>
            <td width="460">
               <input name="Zona" type="text" class="formbutton" id="Zona" size="52" maxlength="150">
            </td>
         </tr>

         <tr>
            <td width="118">
               <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Inscrição:</font>
            </td>
            <td width="460">
               <input name="Inscricao" type="text" class="formbutton" id="Inscricao" size="52" maxlength="150">
            </td>
         </tr>
         
         <tr>
            <td width="118">
               <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Nome do Candidato:</font>
            </td>
            <td width="460">
               <input name="nomeCandidato" type="text" class="formbutton" id="nomeCandidato" size="52" maxlength="150">
            </td>
         </tr>

         <tr>
            <td width="118">
               <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Cargo:</font>
            </td>
            <td width="460">
               <input name="Cargo" type="text" class="formbutton" id="Cargo" size="52" maxlength="150">
            </td>
         </tr>

         <tr>
            <td width="118">
               <font size="1" face="Verdana, Arial, Helvetica, sans-serif">Partido Político:</font>
            </td>
            <td width="460">
               <input name="partidoPolitico" type="text" class="formbutton" id="partidoPolitico" size="52" maxlength="150">
            </td>
         </tr>

         <tr>
            <td height="85">
               <p><strong>
                     <font face="Verdana, Arial, Helvetica, sans-serif">
                        <font size="1">
                        </font>
                     </font>
                  </strong></p>
            </td>
         </tr>
         <tr>
            <td height="22"></td>
            <td>
               <input name="Submit" type="submit" class="formobjects" value="Cadastrar">
               <input name="Reset" type="reset" class="formobjects" value="Limpar campos">
               <button type='submit' formaction='select_variavel_a.php'>Consultar</button>
               <button type='submit' formaction='deletar.php'>Deletar</button>
            </td>
         </tr>
      </table>
   </form>
</html>
