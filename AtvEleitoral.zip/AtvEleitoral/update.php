<?php

include_once "conexao.php";

$nome = $_POST['nome'];
$dataNascimento = $_POST['datadeNascimento'];
$NumDocumento = $_POST['numeroDocumento'];
$dataExpedicao = $_POST['dataExpedicao'];
$Naturalidade = $_POST['Naturalidade'];
$Cidade = $_POST['Cidade'];
$nomePai = $_POST['nomePai'];
$nomeMae = $_POST['nomeMae'];
$Secao = $_POST['Secao'];
$Zona = $_POST['Zona'];
$Inscricao = $_POST['Inscricao'];
$nomeCandidato = $_POST['nomeCandidato'];
$Cargo = $_POST['Cargo'];
$partidoPolitico = $_POST['partidoPolitico'];


$sqlUpdate = "UPDATE users SET user_name = '$nome', user_nascimento = '$dataNascimento', user_documento = '$NumDocumento', user_doxexpedicao = '$dataExpedicao', user_naturalidade = '$Naturalidade', user_cidade = '$Cidade', user_nomepai = '$nomePai', user_nomemae = '$nomeMae', user_secao = '$Secao', user_zona = '$Zona', user_inscricao = '$Inscricao', user_candidato = '$nomeCandidato', user_cargocandidato = '$Cargo', user_partidopolitico = '$partidoPolitico' WHERE user_id = '$codigo'";

if(!mysqli_query($conn,$sqlUpdate)){
    die('Erro ao atualizar o registro'.mysqli_error($conn));
}else{
    echo "Registro atualizado com sucesso. <br>";
}

mysqli_close($conn);
//header("location:select.php");

?>
