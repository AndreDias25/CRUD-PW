<?php

$servidor = "localhost";
$banco = "id18876796_final";
$usuario = "id18876796_root2";
$senha = "andre107Xbox720v8@";
$porta = "3306";

$conn = mysqli_connect($servidor, $usuario, $senha, $banco, $porta);

if (!$conn){
    die("A conexão falhou: " . mysqli_connect_error());
}
echo "A conexão foi efetuada com sucesso!<br>"

?>