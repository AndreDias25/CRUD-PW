-- 1 passo ciar o banco de dados e suas tabelas
-- Base de Dados: 'db_login'

CREATE DATABASE db_login;

-- Estrutura da tabela 'users'
CREATE TABLE IF NOT EXISTS users (
user_id  int(11) NOT NULL AUTO_INCREMENT,
user_name varchar(255) NOT NULL,
user_nascimento varchar(255) NOT NULL,
user_documento int(11) NOT NULL,
user_docexpedicao varchar(255) NOT NULL,
user_naturalidade varchar(255) NOT NULL,
user_cidade varchar(255) NOT NULL,
user_nomepai varchar(255) NOT NULL,
user_nomemae varchar(255) NOT NULL,
user_secao int(11) NOT NULL,
user_zona int(11) NOT NULL,
user_inscricao int(11) NOT NULL,
user_candidato varchar(255) NOT NULL,
user_cargocandidato varchar(255) NOT NULL,
user_partidopolitico varchar(255) NOT NULL,
active int(11) NOT NULL DEFAULT '0',
PRIMARY KEY (`user_id`)

) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

-- Estrutura da tabela `users`
CREATE TABLE IF NOT EXISTS usuarios (
user_id int(11) NOT NULL AUTO_INCREMENT,
user_name varchar(255) NOT NULL,
senha varchar(255) NOT NULL


)

user_name,user_nascimento,user_documento,user_docexpedicao,user_naturalidade,user_cidade,user_nomepai,user_nomemae,user_secao,user_zona,user_inscricao,user_candidato,user_cargocandidato,user_partidopolitico