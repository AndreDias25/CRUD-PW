<?php
require_once "conexao.php";

$nome = $_POST['nome'];
$dataNascimento = $_POST['datadeNascimento'];
$NumDocumento = $_POST['numeroDocumento'];
$dataExpedicao = $_POST['dataExpedicao'];
$Naturalidade = $_POST['Naturalidade'];
$Cidade = $_POST['Cidade'];
$nomePai = $_POST['nomePai'];
$nomeMae = $_POST['nomeMae'];
$Secao = $_POST['Secao'];
$Zona = $_POST['Zona'];
$Inscricao = $_POST['Inscricao'];
$nomeCandidato = $_POST['nomeCandidato'];
$Cargo = $_POST['Cargo'];
$partidoPolitico = $_POST['partidoPolitico'];

echo "Recebi os seguintes valores: $nome, $dataNascimento, $NumDocumento, $dataExpedicao, $Naturalidade, $Cidade, $nomePai, $nomeMae, $Secao, $Zona, $Inscricao, $nomeCandidato, $Cargo e $partidoPolitico<br>";

$sqlInsert = "INSERT INTO users (user_name,user_nascimento,user_documento,user_docexpedicao,user_naturalidade,user_cidade,user_nomepai,user_nomemae,user_secao,user_zona,user_inscricao,user_candidato,user_cargocandidato,user_partidopolitico) values ('$nome', '$dataNascimento', '$NumDocumento', '$dataExpedicao', '$Naturalidade', '$Cidade', '$nomePai', '$nomeMae', '$Secao', '$Zona', '$Inscricao', '$nomeCandidato', '$Cargo', '$partidoPolitico')";



$rs = mysqli_query($conn,$sqlInsert) or die ("Erro ao cadastrar dados". mysqli_error($conn));
 

echo "Dados cadastrados com sucesso!";
?>

<a href="index.php">Voltar</a>