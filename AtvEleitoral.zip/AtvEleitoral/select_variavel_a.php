<?php

date_default_timezone_get('America/Sao_Paulo');

include_once "conexao.php";

//header("Content-type: text/html; charset=utf-8");

echo "<br><br>";

$sqlSelect = "SELECT user_name, user_nascimento,user_documento,user_docexpedicao,user_naturalidade,user_cidade,user_nomepai,user_nomemae,user_secao,user_zona,user_inscricao,user_candidato,user_cargocandidato,user_partidopolitico FROM users";
$rs = mysqli_query($conn, $sqlSelect);

if (mysqli_num_rows($rs) > 0){
    //dados de saída de cada linha
    //mysql_fetch_assoc() busca o resultado de uma linha e o coloca numa matriz associativa, podendo selecionar pelo nome do campo.
    while($row = mysqli_fetch_assoc($rs)){
        echo "Nome: ". $row["user_name"]." - Data de Nascimento: ".date("d/m/Y", strtotime($row["user_nascimento"]))." - Nº do Documento: ".$row["user_documento"]. " - Data de Expedição: ". $row["user_docexpedicao"]." - Naturalidade: ". $row["user_naturalidade"]." - Cidade: ". $row["user_cidade"]." - Nome do Pai: ". $row["user_nomepai"]." - Nome da Mãe: ". $row["user_nomemae"]." - Seção: ". $row["user_secao"]." - Zona Eleitoral: ". $row["user_zona"]." - Inscrição: ". $row["user_inscricao"]." - Candidato: ". $row["user_candidato"]." - Cargo do Candidato: ". $row["user_cargocandidato"]." - Partido Político: ". $row["user_partidopolitico"]."<br>";
    }
} else {
    echo "Não foram encontrados registros cadastrados";
}
mysqli_close($conn)

?>