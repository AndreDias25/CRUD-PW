<?php

//timezone

date_default_timezone_set('America/Sao_Paulo');

//conexão com o banco de dados

define('BD_SERVIDOR','localhost');
define('BD_USUARIO','id19063419_root');
define('BD_SENHA','Xbox720v8@#78');
define('BD_BANCO','id19063419_livraria');