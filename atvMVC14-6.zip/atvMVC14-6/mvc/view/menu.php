<hr>
    <div class="form-group">
        <div ckass="mx-auto" style="1200px"> 
            <a href="cadastro.php" class="btn btn-sucesses">Cadastrar</a>
            <a href="index.php" class="btn btn-default">Consultar</a>
        </div>
    </div>    
<hr>