<?php
include_once "conexao.php";
$acao = $_GET['acao'];

if(isset($_GET['id'])){
    $id = $_GET['id'];
}


switch($acao){
    case 'inserir':

        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $data = $_POST['data'];
        $mensagem = $_POST['mensagem'];

        echo "Recebi os seguintes valores: $nome, $email, $data e $mensagem <br>";

        $sqlInsert = "INSERT INTO users (user_name,user_email,user_data,user_mensagem) values ('$nome', '$email', '$data', '$mensagem')";


        if(!mysqli_query($conn, $sqlInsert)){
            die("Erro ao inserir as informações do formulário na tabela users:".mysqli_error($conn));
        } else{
            echo "<script language='javascript' type='text/javascript'>
            alert('Dados cadastrados com sucesso!')
            window.location.href='index.php'</script>";
        }
        break;
    case 'montar':
        $id = $_GET['id'];
        $sql = 'SELECT * FROM users WHERE user_id ='.$id;
        $resultado = mysqli_query($conn, $sql) or die("Erro ao retornar dados");
        
        //montando formulário
        echo "<form method='post' name='dados' action='crud.php?acao=atualizar' onSubmit='return enviardados();'>";
        echo "<table width='588' border='0' align='center'>";
        
        
        while($registro = mysqli_fetch_array($resultado)){
            echo "    <tr>";
            echo "    <td width='118'><font size='1' face='Verdana, Arial, Helvetica,sans-serif'>Código</font></td>";
            echo "      <td width='460'>";
            echo "     <input name='id' type='text' class='formbutton' id='id' size='5' maxlength='10' value=" . $id. " readonly>";
            echo "      </td>";
            echo "      </tr>";
            
            echo "    <tr>";
            echo "    <td width='118'><font size='1' face='Verdana, Arial, Helvetica,sans-serif'>Nome</font></td>";
            echo "      <td width='460'>";
            echo "     <textarea name='user_name' cols='50' rows='3' class='formbutton'>" . htmlspecialchars($registro['user_name'])."</textarea>" ;
            echo "      </td>";
            echo "      </tr>";
            
            echo "    <tr>";
            echo "    <td width='118'><font size='1' face='Verdana, Arial, Helvetica,sans-serif'>Email</font></td>";
            echo "      <td width='460'>";
            echo "     <textarea name='user_email' cols='50' rows='3' class='formbutton'>" . htmlspecialchars($registro['user_email'])."</textarea>" ;
            echo "      </td>";
            echo "      </tr>";
            
            echo "    <tr>";
            echo "    <td width='118'><font size='1' face='Verdana, Arial, Helvetica,sans-serif'>Data de Cadastro</font></td>";
            echo "      <td width='460'>";
             echo "     <textarea name='user_data' cols='50' rows='3' class='formbutton'>" . htmlspecialchars($registro['user_data'])."</textarea>" ;
            echo "      </td>";
            echo "      </tr>";
            
            echo "    <tr>";
            echo "    <td width='118'><font size='1' face='Verdana, Arial, Helvetica,sans-serif'>Mensagem</font></td>";
            echo "      <td width='460'>";
             echo "     <textarea name='user_mensagem' cols='50' rows='3' class='formbutton'>" . htmlspecialchars($registro['user_mensagem'])."</textarea>" ;
            echo "      </td>";
            echo "      </tr>";
            
            echo "    <tr>";
            echo "    <td height='22'></td>";
            echo "      <td>";
            echo "<input name='Submit' type='submit' class='formobjects' value='Atualizar'>";
            echo "<button class='formobjects' type='submit' formaction='crud.php?acao=selecionar'>Selecionar</button>";
            echo " <input name='Reset' type='reset' class='formobjects' value='Limpar campos'>";
            echo "      </td>";
            echo "      </tr>";
            
            
            echo "</table>";
            echo "</form>";
            
        };
        
        mysqli_close($conn);
        break;
    case 'atualizar':
        $codigo = $_POST['id'];
        $nome = $_POST['user_name'];
        $email = $_POST['user_email'];
        $data = $_POST['user_data'];
        $mensagem = $_POST['user_mensagem'];
        
        $sql = "UPDATE users SET user_name = '".$nome."',user_email ='".$email."',user_data ='".$data."',user_mensagem='".$mensagem."'WHERE user_id='".$codigo."'";
        
        if(!mysqli_query($conn, $sql)){
            die('</br>Erro no comando SQL UPDATE'.mysqli_error($conn));
        } else{
            echo "<script language='javascript' type='text/javascript'>
            alert('Dados atualizado com sucesso!')
            window.location.href='crud.php?acao=selecionar'</script>";
        }
        mysqli_close($conn);
        
        break;
    case 'deletar':
        $sql = "DELETE FROM users WHERE user_id = '" . $id . "'";

        if(!mysqli_query($conn, $sql)){
            die('Error: ' . mysqli_error($conn));
        } else{
        echo "<script language='javascript' type='text/javascript'>
        alert('Dados excluídos com sucesso!')
        window.location.href='crud.php?acao=selecionar'</script>";
        }
        mysqli_close($conn);
        header("Locatio:crud.php?acao=selecionar");
        break;
    case 'selecionar':

        echo "<meta charset='UTF-8'>";
        echo "<center><table border=1>";
        echo "<tr>";
        echo "<th>CODIGO</th>";
        echo "<th>NOME</th>";
        echo "<th>EMAIL</th>";
        echo "<th>DATA CADASTRO</th>";
        echo "<th>MENSAGEM</th>";
        echo "<th>AÇÃO</th>";
        echo "</tr>";
    
        $sql = "SELECT * FROM users";
        $resultado = mysqli_query($conn, $sql) or die("Erro ao retornar dados");
    
        echo "<CENTER>Registros cadastrados na base de dados.<br/></CENTER>";
        echo "</br>";
    
        while($registro = mysqli_fetch_array($resultado)){
            $id = $registro['user_id'];
            $nome = $registro['user_name'];
            $email = $registro['user_email'];
            $data = $registro['user_data'];
            $mensagem = $registro['user_mensagem'];
    
            echo "<tr>";
            echo "<td>" . $id . "</td>";
            echo "<td>" . $nome . "</td>";
            echo "<td>" . $email . "</td>";
            echo "<td>" . date("d/m/Y", strtotime($data)) . "</td>";
            echo "<td>" . $mensagem . "</td>";
            echo "<td><a href='crud.php?acao=deletar&id=$id'><img src='delete.png' alt='Deletar' title='Deletar registro'></a><a href='crud.php?acao=montar&id=$id'><img src='update.png' alt='Atualizar' title='Atualizar registro'></a><a href='index.php'><img src='insert.png' alt='Inserir' title='Inserir registro'></a>";
    
            echo "<tr>";
        }
        mysqli_close($conn);
        break;
    default:
        header("Location:crud.php?acao=selecionar");
        break;
}

?>